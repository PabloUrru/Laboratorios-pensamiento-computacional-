﻿using System ;
class Program {
    static void Main()
    {
        Console.WriteLine("EJERCICIO 1");
        Laboratorio14.CuentaBancaria cuenta1 = new Laboratorio14.CuentaBancaria("pablo" , "002" , 3000);
        Laboratorio14.CuentaBancaria cuenta2 = new Laboratorio14.CuentaBancaria("pablo" , "002" , 3000);
        cuenta1.MostrarInformacion();
        cuenta2.MostrarInformacion();
        Console.WriteLine("Saldo antes del depósito: Q" + cuenta1.saldo);
        cuenta1.Depositar(1000);
        Console.WriteLine("Saldo después del depósito: Q" + cuenta1.saldo);
        Console.WriteLine("Saldo antes del retiro: Q" + cuenta1.saldo);
        cuenta1.Retirar(2000);
        Console.WriteLine("Saldo después del retiro: Q" + cuenta1.saldo);
        Console.WriteLine("Saldo antes del depósito: Q" + cuenta2.saldo);
        cuenta2.Depositar(500);
        Console.WriteLine("Saldo después del depósito: Q" + cuenta2.saldo);
        Console.WriteLine("Saldo antes del retiro: Q" + cuenta2.saldo);
        cuenta2.Retirar(700);
        Console.WriteLine("Saldo después del retiro: Q" + cuenta2.saldo);
        
        Console.WriteLine("EJERCICIO 2");
        Laboratorio14.Producto producto1 = new Laboratorio14.Producto("lapicero", 22.33, 5);
        Laboratorio14.Producto producto2 = new Laboratorio14.Producto("algodon", 1.99, 7);
        producto1.MostrarInfoProducto();
        producto2.MostrarInfoProducto();
        producto1.vender(6);
        producto1.reabastecer(5);
        producto2.vender(5);
        producto2.reabastecer(7);
        
        Console.WriteLine("EJERCICIO 3");
        Laboratorio14.Estudiante estudiante1 = new Laboratorio14.Estudiante("pablo", 33, "tercero", [77, 61, 83]);
        Laboratorio14.Estudiante estudiante2 = new Laboratorio14.Estudiante("pepe", 22, "quinto", [100, 31, 83]);
        Console.WriteLine("ESTUDIANTE 1");
        estudiante1.MostrarinfoEstudiante();
        Console.WriteLine("ESTUDIANTE 2");
        estudiante2.MostrarinfoEstudiante();
        Console.WriteLine("El promedio del estudiante 1 es de:" + estudiante1.CalcularPromedio());
        Console.WriteLine("el promedio del segundo estudiante es de:" + estudiante2.CalcularPromedio());
        Console.WriteLine("ESTUDIANTE 1");
        estudiante1.aprobado();
        Console.WriteLine("ESTUDIANTE 2");
        estudiante2.aprobado();
        estudiante1.NuevaNota(63.4);
        Console.WriteLine("el nuevo promedio del estudiante 1 es de: " + estudiante1.CalcularPromedio());
        
        
        
        

    }
}