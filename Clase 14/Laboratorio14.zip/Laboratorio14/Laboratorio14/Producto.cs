namespace Laboratorio14;

public class Producto
{
    public string nombre;
    public double precio;
    public int cantidad;
    
    public Producto (string nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad; }

    public void MostrarInfoProducto() {
        Console.WriteLine("Nombre: " + nombre);
        Console.WriteLine("Precio: " + precio);
        Console.WriteLine("Cantidad: " + cantidad); }

    public void vender(int cantVender)
    {
        if (cantVender <= cantidad)
        {
            cantidad -= cantVender;
            Console.WriteLine("Cantidad nueva: " + cantidad);
        }
        else
            {
            Console.WriteLine("no puede vender tantos productos");
            }
    }

    public void reabastecer(int cantidadReabastecer) {
        cantidad += cantidadReabastecer;
        Console.WriteLine("Cantidad nueva: " + cantidad);
    }
}

