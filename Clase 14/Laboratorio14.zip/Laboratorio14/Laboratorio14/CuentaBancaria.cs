namespace Laboratorio14;

public class CuentaBancaria
{
    public string titular;
    public string numeroCuenta;
    public double saldo;
    
    public CuentaBancaria(string titular, string numeroCuenta, double saldo)
    {
        this.titular = titular;
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
    }
    public void MostrarInformacion()
    {
        Console.WriteLine("Titular: " + titular);
        Console.WriteLine("Número de cuenta: " + numeroCuenta);
        Console.WriteLine("Saldo: Q" + saldo);
    }
    public void Depositar(double monto)
    {
        saldo += monto;
        Console.WriteLine("Se depositaron Q" + monto);
    }
    public void Retirar(double monto)
    {
        if (monto <= saldo)
        {
            saldo -= monto;
            Console.WriteLine("Se retiraron Q" + monto);
        }
        else
        {
            Console.WriteLine("Fondos insuficientes.");
        }
    }
    
}
