namespace Laboratorio14;

public class Estudiante
{
    public string nombre;
    public int edad;
    public string grado;
    public double[] notas;

    public Estudiante(string nombre, int edad, string grado, double[] notas)
    {
        this.nombre = nombre;
        this.edad = edad;
        this.grado = grado;
        this.notas = notas;
    }

    public double CalcularPromedio()
    {
        double promedio = 0;
        for (int i = 0; i < notas.Length; i++)
        {
            promedio += notas[i];
        } 
        promedio /= notas.Length;
        return promedio;
    }

    public void aprobado()
    {
        if (CalcularPromedio() >= 61) {
            Console.WriteLine("el estudiante aprobo");
        }
        else
        {
            Console.WriteLine("el estudiante reprobo");
        }
    }

    public void MostrarinfoEstudiante()
    {
        Console.WriteLine("Nombre: " + nombre);
        Console.WriteLine("Edad: " + edad);
        Console.WriteLine("Grado: " + grado);
        Console.WriteLine("Notas: ");
        for (int i = 0; i < notas.Length; i++) {
            Console.WriteLine(notas[i]); }
    }

    public void NuevaNota(double notaextra) {
        double[] nuevasNotas = new double[notas.Length + 1];
        for (int i = 0; i < notas.Length; i++)
        {
            nuevasNotas[i] = notas[i];
        }
        nuevasNotas[nuevasNotas.Length - 1] = notaextra;
        notas = nuevasNotas;
    }
}