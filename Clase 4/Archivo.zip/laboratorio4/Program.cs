﻿class Program
{
    static void Main()
    {
//ejercico 1
string nombre = "pablo"; 
int nivel = 23; 
double puntos = 2233.223; 
bool jefe = true; 
Console.WriteLine("Usted es " +nombre+ ", usted se encuentra en el nivel " +nivel+", usted tiene " +puntos+ " puntos, y usted es jefe? " +jefe); 

//ejercicio 2
int numeroEntero = 1500; 
long numeroLargo = numeroEntero; 
numeroLargo = numeroEntero; 
double numeroDecimal = numeroLargo; 
Console.WriteLine(numeroDecimal);

//ejercicio 3
double precioExacto = 45.89; 
int precioRedondeado = (int)precioExacto; 
Console.WriteLine("el precio exacto es " +precioExacto+ " y el precio redondeado es " + precioRedondeado);

//ejercicio 4
Console.WriteLine("escriba un numero"); 
string entradaUsuario= Console.ReadLine(); 
int entradaUsuarioInt = int.Parse(entradaUsuario); 
int numero2 = 5;
int sumaNumero = numero2 + entradaUsuarioInt ; 
Console.WriteLine(sumaNumero); 

//ejercicio 5
string valorBooleano = "true"; 
bool boolConvertido = Convert.ToBoolean(valorBooleano);
string valorDecimal = "25.5"; 
double decimalConvertido = Convert.ToDouble(valorDecimal); 
Console.WriteLine("El valor decimal es: " + decimalConvertido + ", el valor booleano es: " + boolConvertido); 

// ejercicio 6
double pi = 3.14159265; 
string pi2 = pi.ToString(); 
Console.WriteLine("pi es " + pi2); 

//ejercicio 7
Console.WriteLine("precio de un producto"); 
double precioProducto = double.Parse(Console.ReadLine()); 
double IVA = 0.21; 
double precioIva = precioProducto * IVA; 
double precioTotal = precioIva + precioProducto;
int precioTotalSinDecimal = (int)precioTotal; 
Console.WriteLine("El precio con IVA incluido es de: " +precioTotalSinDecimal); Console.WriteLine();

Console.ReadKey();
    }
}