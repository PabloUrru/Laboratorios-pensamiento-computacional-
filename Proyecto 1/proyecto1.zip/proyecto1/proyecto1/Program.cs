﻿class Program
{
    static void Main()
    {
        int ticketCerrado = 0;
        int ticketCreado = 0;
        int tiempoSimulado = 0;
        double dineroRecaudado = 0;
        int vehiculo = 0;
        int capacidad = 0;
        bool ticketActivo = false;
        int minutoEntrada = tiempoSimulado;
        Console.WriteLine("Ingrese su nombre");
        string nombreOperador = Console.ReadLine();
        Console.WriteLine("Ingrese su codigo de turno");
        string codigoTurno = Console.ReadLine();
        while (codigoTurno.Length != 4)
        {
            Console.WriteLine("Código incorrecto. Debe tener  4 caracteres.");
            Console.Write("Ingrese código de turno nuevamente: ");
            codigoTurno = Console.ReadLine();
        }

        Console.Write("Ingrese capacidad del parqueo (mínimo 10): ");
        int capacidadTotal = int.Parse(Console.ReadLine());
        while (capacidadTotal < 10)
        {
            Console.WriteLine("incorrecto . Debe ser mínimo 10.");
            Console.Write("Ingrese capacidad del parqueo nuevamente: ");
            capacidadTotal = int.Parse(Console.ReadLine());
        }

        int opcion = 0;

        do
        {
            Console.WriteLine("1. crear ticket");
            Console.WriteLine("2. registrar salida y calcular cobro");
            Console.WriteLine("3. ver estado del parqueo ");
            Console.WriteLine("4. simular paso del tiempo ");
            Console.WriteLine("5. salir");
            opcion = int.Parse(Console.ReadLine());
            if (opcion == 1)
            {
                if (ticketActivo)
                {
                    Console.WriteLine("No puede tener mas de un ticket a la vez");
                }
                else if (capacidad >= capacidadTotal) {
                    Console.WriteLine("El parqueo está lleno");
                }
                else
                {

                    Console.WriteLine("ingrese numero de placa");
                    string placa = Console.ReadLine();
                    while (placa.Contains(" ") || placa.Length < 6 || placa.Length > 8) {
                        Console.WriteLine("placa no valida (6 a 8 caracteres, sin espacios)");
                        placa = Console.ReadLine(); }
                    Console.WriteLine("Ingrese tipo de vehículo (1=Moto, 2=Auto, 3=Pickup/SUV)");
                    vehiculo = int.Parse(Console.ReadLine());
                    Console.WriteLine("Ingrese nombre del cliente:");
                    string nombreCliente = Console.ReadLine();
                    ticketActivo = true;
                    ticketCreado++;
                    capacidad++;
                    minutoEntrada = tiempoSimulado;
                }
            }
            else if (opcion == 2)
            {
                
                Console.WriteLine("ingrese minutos actuales");
                int minutos = int.Parse(Console.ReadLine());
                tiempoSimulado = minutos;
                double monto = 0;
                if (ticketActivo == false) {
                    Console.WriteLine("no puede realizar un pago si no tiene un ticket activo"); }
                else
                {
                    int minutosEstacionados = minutos - minutoEntrada;
                    int horasEstacionados = (minutosEstacionados + 59 )/ 60;
                    if (minutosEstacionados <= 15) {
                        Console.WriteLine("usted no debe pagar parqueo"); }
                    if (minutosEstacionados > 15) {
                        if (vehiculo == 1) {
                            monto = horasEstacionados * 5; }
                        else if (vehiculo == 2) {
                            monto = horasEstacionados * 10; }
                        else if (vehiculo == 3) {
                            monto = horasEstacionados * 15; }
                        else {
                            Console.WriteLine("vehiculo no encontrado"); } }

                    if (horasEstacionados > 6) {
                        Console.WriteLine("usted tiene multa de 25 quetzales");
                        monto = monto + 25; }
                    
                    Console.WriteLine("es usted cliente VIP?");
                    bool clienteVIP = bool.Parse(Console.ReadLine());
                    if (clienteVIP == true) {
                       monto = monto * 0.90; }
                    else {
                        monto = monto * 1; }
                    Console.WriteLine("el monto a pagar es de:" + monto);
                    dineroRecaudado = dineroRecaudado + monto;
                    ticketCerrado ++ ;
                    capacidad--;
                    ticketActivo = false; } }

            if (opcion == 3) {
                Console.WriteLine("El estado del parqueo es: ");
                Console.WriteLine("capacidad total" + capacidadTotal);
                Console.WriteLine("espacios ocupados " + capacidad);
                int espaciosDisponibles = capacidadTotal -  capacidad;
                Console.WriteLine("los espacios disponibles son:  " + espaciosDisponibles);
                Console.WriteLine("el tiempo simulado es: " + tiempoSimulado);
                Console.WriteLine("el dinero recaudado es: " + dineroRecaudado);
                Console.WriteLine("los tickets creados son: " + ticketCreado + "los tickets cerrados son:"  + ticketCerrado);
                
            }

            
        }
        while (opcion != 5);

    }
}
            
