﻿using System;
static void Main()
{
    double capital = 1000;
    double tasa = 0.05;
    double intereses = 0;
    double abonos = 0;

    for (int mes = 1; mes <= 12 && capital > 0; mes++)
    {
        // calculo de intereses del mes
        intereses = capital * tasa;
        
        // abono realizado cada mes 
         abonos = 100 + (mes*10);
         
         // actualizacion del capital 
         Console.ReadLine();
         capital = capital + intereses -abonos;
    }

    Console.ReadKey();
}