﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ejercicio 1");
        Console.WriteLine("ingrese una palabra");
        string palabra = Console.ReadLine().ToLower();
        string invertida = ""; 
        for (int i = palabra.Length - 1; i >= 0; i--) {
            invertida += palabra[i]; }
        if (palabra == invertida) {
            Console.WriteLine("True"); }
        else {
            Console.WriteLine("False"); }
        
        Console.WriteLine("ejercicio 2");
        string[] espanol = { "rojo", "azul", "amarillo", "blanco", "verde" };
        string[] ingles = { "red", "blue", "yellow", "white", "green" };
        string[] italiano = { "rosso", "blu", "giallo", "bianco", "verde" };
        int opcion = 0;
        do
        {
            Console.WriteLine("que opcion desea realizar?");
            Console.WriteLine("1. practicar leccion");
            Console.WriteLine("2. terminar leccion");
            opcion = int.Parse(Console.ReadLine());
            if (opcion == 1)
            {
                Console.WriteLine("ingrese una palabra en español");
                string palabrita = Console.ReadLine().ToLower();
                bool traduccion = false;
                for (int i = 0; i < espanol.Length; i++)
                {
                    if (palabrita == espanol[i])
                    {
                        Console.WriteLine(espanol[i] + ", " + ingles[i] + ", " + italiano[i]);
                        traduccion = true;
                    }
                }
                if (!traduccion)
                {
                    Console.WriteLine("No encontrada");
                }
            }
        } while (opcion != 2);
        
        Console.WriteLine("Ejercicio 3");
        int[] notas = new int[10];
        Random r = new Random();
        for (int i = 0; i < notas.Length; i++) {
            notas[i] = r.Next(50, 101); }
        int option;
        do
        {
            Console.WriteLine("1. Reporte de rendimiento");
            Console.WriteLine("2. Estadísticas");
            Console.WriteLine("3. Salir");
            option = int.Parse(Console.ReadLine());
            if (option == 1)
            {
                for (int i = 0; i < notas.Length; i++)
                {
                    if (notas[i] <= 64)
                        Console.ForegroundColor = ConsoleColor.Red;

                    else if (notas[i] <= 79)
                        Console.ForegroundColor = ConsoleColor.Yellow;

                    else
                        Console.ForegroundColor = ConsoleColor.Green;

                    Console.Write(notas[i] + " ");
                }

                Console.ResetColor();
                Console.WriteLine();
            }

            else if (option == 2)
            {
                int suma = 0;
                int mayor = notas[0];
                int menor = notas[0];

                for (int i = 0; i < notas.Length; i++)
                {
                    suma += notas[i];

                    if (notas[i] > mayor)
                        mayor = notas[i];

                    if (notas[i] < menor)
                        menor = notas[i];
                }

                double promedio = (double)suma / notas.Length;

                Console.WriteLine("Promedio: " + promedio);
                Console.WriteLine("Nota más alta: " + mayor);
                Console.WriteLine("Nota más baja: " + menor);
            }

        } while (option != 3);
        Console.WriteLine("Ejercicio 4");
        string[] nombres = { "Ana", "Mario", "Saúl", "Karla", "María", "José" };
        double[] salario_x_hora = { 100, 125.50, 98.65, 125, 132.50, 102.50 };
        double[] horas_laboradas = new double [6];
        
        for (int i = 0; i < nombres.Length; i++)
        {
            Console.Write("horas trabajadas por " + nombres[i] + ": ");
            horas_laboradas[i] = double.Parse(Console.ReadLine());
        }

        Console.WriteLine("pagos semanales:");
        for (int i = 0; i < nombres.Length; i++)
        {
            double pago;

            if (horas_laboradas[i] <= 40)
            {
                pago = horas_laboradas[i] * salario_x_hora[i];
            }
            else
            {
                double horasExtra = horas_laboradas[i] - 40;

                pago = (40 * salario_x_hora[i]) +
                       (horasExtra * salario_x_hora[i] * 1.5);
            }

            Console.WriteLine(nombres[i] + "Q" + pago);
        }
    }
}



    

