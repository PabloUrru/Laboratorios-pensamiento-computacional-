﻿class Program
{
    static void Main()
    {
        Console.WriteLine("EJERCICIO 01");
        Console.WriteLine("Ingrese su nombre");
        string  nombre = Console.ReadLine();
        Console.WriteLine("Ingrese su carnet");
        int carnet = int.Parse(Console.ReadLine());
        int indice = 1;
        Console.WriteLine("su nombre es: " + nombre + " su carnet es: " + carnet);
        while (indice <= 20)
        {
            if (indice % 2 == 0)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Green;
            }

            Console.WriteLine(indice);
            indice = indice + 1; }
        Console.ForegroundColor = ConsoleColor.Black;
        Console.WriteLine("EJERCICO 02");
        Console.WriteLine("Ingrese un numero entero");
        int numero = int.Parse(Console.ReadLine());
        int div = 1;
        if (numero > 0) {
            Console.WriteLine("divisores de "+numero);
            do {
                if (numero % div == 0) {
                    Console.WriteLine(div);
                }
                div++;
            } while (div <= numero);
            
            Console.WriteLine("EJERCICO 03");
            Console.WriteLine("ingrese un numero entero");
            int numero1 = int.Parse(Console.ReadLine());
            int Inicio1 = 0;
            int Inicio2 = 1;
            for (int inicio = 0; inicio < numero1; inicio++ ) {
                Console.WriteLine(Inicio1 );
                int temp = Inicio1 + Inicio2 ;
                Inicio1 = Inicio2;
                Inicio2 = temp;
            }
            
            Console.WriteLine("EJERCICO 04");
            for (int tablaM = 1; tablaM <= 12; tablaM++) {
                Console.WriteLine("tabla del " + tablaM);
                for (int tabla1 = 1; tabla1 <= 10; tabla1++)
                {
                    int resultado1 = tabla1 * tablaM;
                    Console.WriteLine(tablaM + "X" + tabla1 + " = " + resultado1);
                }

                Console.ReadKey();
            }










        }


    }
}