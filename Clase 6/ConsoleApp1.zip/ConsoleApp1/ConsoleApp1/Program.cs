﻿class Program
{
    static void Main()
    {
        Console.WriteLine("EJERCICIO 01");
        Console.WriteLine("Usted puede convertir la siguientes temperaturas:");
        Console.WriteLine("1. De celsius a fahrenheit");
        Console.WriteLine("2. De Fahrenheit a Celsius");
        Console.WriteLine("3. De Celsius a Kelvin");
        Console.WriteLine("cual de las opciones desea converir?");
        int conversion = int.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese la cantidad que desea convertir");
        double cantidad = double.Parse(Console.ReadLine());
        double cantidadConvertida = 0;
        if (conversion != 1 && conversion != 2 && conversion != 3) {
            Console.WriteLine("La conversion no existe en el programa"); }
        else if (conversion == 1) {
            cantidadConvertida = (cantidad * 9/5) +32;
            Console.WriteLine("Convertido de celcius a fahrenheit=  " + cantidadConvertida); }
        else if (conversion == 2) {
            cantidadConvertida = (cantidad - 32) * 5/9;
            Console.WriteLine("la conversion de Fahrenheit a Celsius es de:" + cantidadConvertida); }
        else {
            cantidadConvertida = (cantidad + 273.15);
            Console.WriteLine("La conversion de Celsius a Kelvin es de:" + cantidadConvertida); }
        
        Console.WriteLine("EJERCICIO 02");
        Console.WriteLine("Los tipos de clientes existentes son: 1. Cliente regular y 2:Cliente VIP");
        Console.WriteLine("Que tipo de cliente es usted, 1 o 2?");
        int cliente = int.Parse(Console.ReadLine());
        if (cliente != 1 && cliente != 2) {
            Console.WriteLine("Usted no es ningun tipo de cliente"); }
        Console.WriteLine("cuantas unidades comprara?");
        int cantidad1 = int.Parse(Console.ReadLine());
        bool mayorista = cantidad1 >= 100;
        double precioRegular = cantidad1 * 0.95;
        double precioVIP = cantidad1 * 0.90;
        double precioMayorista = cantidad1 * 0.85;
        double preciofinal = 0;
        if (cliente == 1)  {
           preciofinal = mayorista ? precioMayorista : precioRegular; }
        else{
            preciofinal = mayorista ? precioMayorista : precioVIP;
        }
        Console.WriteLine("el precio final es de:"  + preciofinal);
        
        Console.WriteLine("EJERCICIO 03");
        Console.WriteLine("Ingrese el numero de horas que estuvo en el parqueo");
        int numeroHoras = int.Parse(Console.ReadLine());
        int totalP = 0;
        if (numeroHoras < 2)
        {
            totalP = numeroHoras * 5;
                Console.WriteLine("su total a pagar es de: " + totalP); }
        else if (numeroHoras >= 2 && numeroHoras < 5)  {
            totalP = numeroHoras * 4;
            Console.WriteLine("su total a pagar es de: " + totalP); }
        else { 
            totalP = numeroHoras * 3;
            Console.WriteLine("su total a pagar es de: " + totalP); }
        
        Console.WriteLine("EJERCICIO 04");
        Console.WriteLine("Ingrese su nota obtenida en el examen:");
        double nota = double.Parse(Console.ReadLine());
        double bono = nota * 2400;
        switch (nota)
        {
            case 0.0:
                Console.WriteLine("su rendimiento es inaceptable, su bono es de:" + bono); 
                break;
            case 0.4:
                Console.WriteLine("su rendimiento es aceptable , su bono es de: "  + bono); 
                break;
            case >= 0.6:
                Console.WriteLine("su rendimiento es meritorio, su bono es de: " + bono);
                break;
            default:
                Console.WriteLine("no existe esta puntuacion");
                break;
        }

        Console.ReadKey();
    }
}