using System;
namespace Lab13;

public class Persona
{
        public string nombre;
        public int edad;
        public double altura; 
        public bool estudiante;
}
