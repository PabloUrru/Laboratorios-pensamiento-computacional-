﻿using System;
public class Program
{
    static void Main()
    {
        Console.WriteLine("EJERCICIO 1");
        Lab13.Persona p1 = new Lab13.Persona(); 
        p1.nombre = "pablo";
        p1.edad = 18;
        p1.altura = 1.80;
        p1.estudiante = true;
        Console.WriteLine("Nombre: " + p1.nombre);
        Console.WriteLine("Edad: " + p1.edad);
        Console.WriteLine("Altura: " + p1.altura);
        Console.WriteLine("Estudiante: " + p1.estudiante);
        
        Console.WriteLine("EJERCICIO 2");
        Lab13.vehiculo v1 = new Lab13.vehiculo();
        v1.marca = "kia";
        v1.modelo = "soul";
        v1.anio = 2021;
        v1.color = "rojo";
        v1.placa = "P992GGL";
        Console.WriteLine("marca: " + v1.marca);
        Console.WriteLine("modelo: " + v1.modelo);
        Console.WriteLine("anio: " + v1.anio);
        Console.WriteLine("color: " + v1.color);
        Console.WriteLine("placa: " + v1.placa);
        
        Console.WriteLine("EJERCICIO 3");
        Lab13.producto pr1 = new Lab13.producto();
        pr1.codigo = "jiihjbn8";
        pr1.nombre = "salchicha";
        pr1.precio = 150;
        pr1.stock = 10000;
        pr1.disponible = true;
        Console.WriteLine("codigo: " + pr1.codigo);
        Console.WriteLine("Nombre: " + pr1.nombre);
        Console.WriteLine("Precio: " + pr1.precio);
        Console.WriteLine("Stock: " + pr1.stock);
        Console.WriteLine("disponible: " + pr1.disponible);
        Lab13.producto pr2 = new Lab13.producto();
        pr2.codigo = "jjhjn8";
        pr2.nombre = "rafalandivar";
        pr2.precio = 1000000000;
        pr2.stock = 1;
        pr2.disponible = true;
        Console.WriteLine("codigo: " + pr2.codigo);
        Console.WriteLine("Nombre: " + pr2.nombre);
        Console.WriteLine("Precio: " + pr2.precio);
        Console.WriteLine("Stock: " + pr2.stock);
        Console.WriteLine("disponible: " + pr2.disponible);
        Console.WriteLine("EJERCICIO 4");
        Lab13.mascota m1 = new Lab13.mascota();
        m1.nombre = "cochon";
        m1.especie = "poodle";
        m1.edad = 3;
        m1.peso = 22;
        m1.vacunado =  false;
        Console.WriteLine("nombre: " + m1.nombre);
        Console.WriteLine("especie: " + m1.especie);
        Console.WriteLine("edad: " + m1.edad);
        Console.WriteLine("peso: " + m1.peso);
        Console.WriteLine("vacunado: " + m1.vacunado);
    }
}