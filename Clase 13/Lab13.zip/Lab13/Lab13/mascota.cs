using System;
namespace Lab13;

public class mascota
{
    public string nombre;
    public string especie;
    public int edad;
    public double peso;
    public bool vacunado;

    
}