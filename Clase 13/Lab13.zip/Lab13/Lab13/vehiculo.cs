using System;
namespace Lab13;

public class vehiculo
{
    public string marca;
    public string modelo;
    public int anio;
    public string color;
    public string placa;
}