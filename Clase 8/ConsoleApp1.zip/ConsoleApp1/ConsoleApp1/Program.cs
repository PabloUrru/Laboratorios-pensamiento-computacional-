﻿class Program
{
    static void Main()
    {
        
        Console.WriteLine("EJERCICIO 1");
        int num2 = 0;
        int menor = 0;
        int mayor = 0;
        int suma = 0;
        for (int num = 0; num < 1; num++)
        {
            Console.WriteLine("ingrese un numero");
            num2 = int.Parse(Console.ReadLine());
            if (num ==0)
                menor = num2;
            if (num2 > mayor)  {
                mayor = num2; }
            if (num2 < menor) {
                menor = num2; }
            suma = num2 + suma; }
        Console.WriteLine("el numero menor es:" + menor);
        Console.WriteLine("el numero mayor es:" + mayor);
        Console.WriteLine("el promedio es" + suma/20);
        
        
        Console.WriteLine("EJERCICIO 02");
        int num3 = 0;
        for (int num = 1; num <= 100; num++) {
            ++ num3;
            Console.WriteLine(num3);
            if (num3 % 7 == 0 && num3 % 2 == 0) {
                Console.WriteLine("parSIETE"); }
            else if (num3 % 7 == 0) {
                Console.WriteLine("SIETE"); }
            else if (num3 % 2 == 0) {
                Console.WriteLine("PAR"); }
        }
        
        Console.WriteLine("EJERCICIO 03");
        double total = 0;
        int descuento1 = 0;
        int descuento2 = 0;
        double ventas = 0;
        for (int i = 0; i < 10; i++) {
            Console.WriteLine("ingrese el total de su compra");
            total = double.Parse(Console.ReadLine());
            if (total > 700) {
                total = total * 0.88; 
                Console.WriteLine("el total de su compra es" + total);
                descuento1++; }
            else if (total > 300 && total <= 700) {
                total = total * 0.95;
                Console.WriteLine("el total es: " + total);
                descuento2++; }
            Console.WriteLine(" el total de su compra es" + total);
            ventas = ventas + total;
        }
        Console.WriteLine(" las personas con descuento de 12 % son:" + descuento1 );
        Console.WriteLine(" las personas con descuento de 5 % son:" + descuento2);
        Console.WriteLine("el total de ventas son"  + ventas);
        
        Console.WriteLine("EJERCICIO 04");
        Console.WriteLine("ingrese un entero:");
        int entero = int.Parse(Console.ReadLine());
        Console.WriteLine("que accion desea realizar? 1. Mostrar los números desde el número ingresado hasta 2. Mostrar los múltiplos de 3 hasta el número ingresado 3.Mostrar los múltiplos de 5 hasta el número ingresado");
        int accion = int.Parse(Console.ReadLine());
        if (accion == 1) {
            for (int i = entero; i>= 1; i--) {
                Console.WriteLine(i); } }
        else if (accion == 2) {
            for (int i = entero; i >= 1; i--) {
                if (i % 3 == 0) {
                    Console.WriteLine(i); } } }
        else if (accion == 3) {
            for (int i = entero; i >= 1; i--) {
                if (i % 5 == 0) {
                    Console.WriteLine(i); } } }
        else {
            Console.WriteLine("accion no valida"); }
       
        
        Console.WriteLine("EJERCICIO 05");
        Console.WriteLine("ingrese cuantas filas desea que tenga su triangulo de asteriscos");
        int filas = int.Parse(Console.ReadLine());
        for (int i = 1; i <=filas; i++) {
            for (int o = 1; o <= i; o++) {
                Console.Write("*");
            }
            Console.WriteLine(" ");
        }
        
    }
}