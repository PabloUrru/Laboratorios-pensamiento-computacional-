namespace Proyecto2;

public class Granja
{
    public int meses;
    public int empleados;
    public double capitalInicial;
    public double sueldoMensual;
    public int filas;
    public int columnas;
    public double DineroActual;
    public double IngresosTotales;
    public double MateriaPrimaTotal;
    public double ManoObraTotal;
    public Inventario Inventario;
    public Parecla[,] parcela;
    
// constructor de la granja 
    public Granja(int meses, int empleados, double CapitalInicial, double sueldoMensual, int filas, int columnas)
    {
        this.meses = meses;
        this.empleados = empleados;
        this.capitalInicial = CapitalInicial;
        this.sueldoMensual = sueldoMensual;
        this.filas = filas;
        this.columnas = columnas;
        this.DineroActual = CapitalInicial;
        this.Inventario = new Inventario();
        this.parcela = new Parecla[filas, columnas];
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                parcela[i, j] = new Parecla(); } } }

    // GET Y SET DE MESES
    public int Meses {
        get { return meses; }
        set { meses = value; } }
    // GET Y SET DE EMPLEADOS
    public int Empleados {
        get { return empleados; }
        set { empleados = value; } }

    // GET Y SET DE CAPITAL INICIAL
    public double CapitalInicial {
        get { return capitalInicial; }
        set { capitalInicial = value; } }

    // GET Y SET DE SUELDO MENSUAL
    public double SueldoMensual {
        get { return sueldoMensual; }
        set { sueldoMensual = value; } }
    
    // GET Y SET DE FILAS
    public int Filas{
        get { return filas; }
        set { filas = value; } }
    
    // GET Y SET DE FILAS
    public int Columnas{
        get { return columnas; }
        set { columnas = value; } }
    

    public Inventario Inventario1
    {
        get => Inventario;
        set => Inventario = value ?? throw new ArgumentNullException(nameof(value));
    }
}