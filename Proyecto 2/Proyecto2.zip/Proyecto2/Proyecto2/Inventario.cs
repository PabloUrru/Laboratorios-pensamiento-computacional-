namespace Proyecto2;

public class Inventario
{
    public int CantTrigo;
    public int CantRepollo;
    public int CantTomate;
    public int CantCalabaza;
    public int CantEsparrago;
    
    
    
    
    public void MostrarInfoInventario() {
        Console.WriteLine("Cantidad de trigo:" + CantTrigo);
        Console.WriteLine("Cantidad de repollo:" + CantRepollo);
        Console.WriteLine("Cantidad de Tomate:" + CantTomate);
        Console.WriteLine("Cantidad de calabaza:" + CantCalabaza);
        Console.WriteLine("Cantidad de Esparrago:" + CantEsparrago); }
}