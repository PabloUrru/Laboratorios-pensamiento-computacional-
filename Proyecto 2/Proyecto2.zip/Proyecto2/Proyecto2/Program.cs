﻿using System ;
using System.Runtime.CompilerServices;
using Proyecto2;

class Program
{
    static void Main()
    {
        Console.ForegroundColor = ConsoleColor.DarkYellow;
        Console.WriteLine("==========BIENVENIDO A LA SIMULACION DE GRANJAS==========");
        Console.WriteLine("¡ ¡ ¡ ¡ INGRESE SUS DATOS PARA INICIAR LA SIMULACION ! ! ! ! ");
        Proyecto2.Granja granja1 = IngresarDatos();
        bool salir = false;
        do
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("======¿QUE ACCION DESEA REALIZAR?======");
            Console.WriteLine("1. COMPRAR SEMILLAS");
            Console.WriteLine("2. SEMBRAR");
            Console.WriteLine("3. CONSULTAR PARCELAS");
            Console.WriteLine("4. AVANZAR DE MES");
            Console.WriteLine("5. SALIR");
            Console.ForegroundColor = ConsoleColor.Black;
            int opcion = int.Parse(Console.ReadLine());
            switch (opcion)
            {
                case 1:
                    ComprarSemillas(granja1);
                    break;
                case 2:
                    Sembrar(granja1);
                    break;
                case 3:
                    ConsultarParcelas(granja1);
                    break;
                case 4:
                    AvanzarMes(granja1);
                    break;
                case 5:
                    salir = true;
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("opcion no valida");
                    Console.ForegroundColor = ConsoleColor.Black;
                    break;
            }
        } while (granja1.meses >= 0 && salir == false && granja1.DineroActual >= 0);
        ReporteFinal(granja1);
    }

// ingresar los datos para crear la granja
    public static Granja IngresarDatos()
    {
        double capitalInicial;
        int meses;
        int empleados;
        double sueldoMensual;
        int filas;
        int columnas;

        do
        {
            Console.WriteLine("Ingrese su capital para comenzar su granja:");
            capitalInicial = double.Parse(Console.ReadLine());
            if (capitalInicial <= 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("ERROR: Solo puede ingresar números mayores a 0.");
            }
        } while (capitalInicial <= 0);

        do
        {
            Console.WriteLine("Ingrese la cantidad de meses a simular:");
            meses = int.Parse(Console.ReadLine());
            if (meses <= 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("ERROR: Solo puede ingresar números mayores a 0.");
            }
        } while (meses <= 0);

        do
        {
            Console.WriteLine("Ingrese la cantidad de empleados que desea tener: ");
            empleados = int.Parse(Console.ReadLine());
            if (empleados <= 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("ERROR: Solo puede ingresar números mayores a 0.");
            }
        } while (empleados <= 0);

        do
        {
            Console.WriteLine("Ingrese el sueldo de los empleados:");
            sueldoMensual = double.Parse(Console.ReadLine());
            if (sueldoMensual <= 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("ERROR: Solo puede ingresar números mayores a 0.");
            }
        } while (sueldoMensual <= 0);

        do
        {
            Console.WriteLine("Ingrese las columnas de las parcelas:");
            filas = int.Parse(Console.ReadLine());
            if (filas <= 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("ERROR: Solo puede ingresar números mayores a 0.");
            }
        } while (filas <= 0);

        do
        {
            Console.WriteLine("Ingrese las columnas de las parcelas:");
            columnas = int.Parse(Console.ReadLine());
            if (columnas <= 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("ERROR: Solo puede ingresar números mayores a 0.");
            }
        } while (columnas <= 0);


        Proyecto2.Granja granja1 = new Granja(meses, empleados, capitalInicial, sueldoMensual, filas, columnas);
        return granja1;
    }

// Ejecutar la opcion 1 del menu, comprar semillas
    static void ComprarSemillas(Granja granja1)
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Su dinero actual es de:" + granja1.DineroActual);
        Console.WriteLine("Los costos mensuales proyectados son: " + costosProyectados(granja1));
        Console.WriteLine("Su utilidad es de: " + utilidad(granja1));
        if (utilidad(granja1) >= 0)
        {
            Console.WriteLine("====SELECCIONE LA SEMILLA A COMPRAR====");
            mostrarInfoPlantas();
            int opcionSiembra = int.Parse(Console.ReadLine());

            switch (opcionSiembra)
            {
                case 1:
                    Console.WriteLine("ingrese la cantidad de trigo a comprar");
                    int cantidadCompra = int.Parse(Console.ReadLine());
                    if (cantidadCompra <= 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("cantidad no valida");
                    }
                    else
                    {
                        if (utilidad(granja1) > 110 * cantidadCompra)
                        {
                            granja1.DineroActual -= cantidadCompra * 110;
                            granja1.Inventario.CantTrigo += cantidadCompra;
                            granja1.MateriaPrimaTotal += cantidadCompra * 110;
                            Console.WriteLine("Compra realizada con exito");
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("no tiene los fondos suficientes");
                        }
                    }

                    break;
                case 2:
                    Console.WriteLine("Ingrese la cantidad de repollo a comprar");
                     cantidadCompra = int.Parse(Console.ReadLine());
                    if (cantidadCompra <= 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Cantidad no válida");
                    }
                    else
                    {
                        if (utilidad(granja1) >= 180 * cantidadCompra)
                        {
                            granja1.DineroActual -= cantidadCompra * 180;
                            granja1.Inventario.CantRepollo += cantidadCompra;
                            granja1.MateriaPrimaTotal += cantidadCompra * 180;
                            Console.WriteLine("Compra realizada correctamente");
                        }
                        else
                        {
                            Console.WriteLine("No tiene los fondos suficientes");
                        }
                    }

                    break;
                case 3:
                    Console.WriteLine("Ingrese la cantidad de tomate a comprar");
                    cantidadCompra = int.Parse(Console.ReadLine());
                    if (cantidadCompra <= 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Cantidad no válida");
                    }
                    else
                    {
                        if (utilidad(granja1) >= 250 * cantidadCompra)
                        {
                            granja1.DineroActual -= cantidadCompra * 250;
                            granja1.Inventario.CantTomate += cantidadCompra;
                            Console.WriteLine("Compra realizada correctamente");
                            granja1.MateriaPrimaTotal += cantidadCompra * 250;
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("No tiene los fondos suficientes");
                        }
                    }

                    break;
                case 4:
                    Console.WriteLine("Ingrese la cantidad de calabaza a comprar");
                    cantidadCompra = int.Parse(Console.ReadLine());
                    if (cantidadCompra <= 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Cantidad no válida");
                    }
                    else
                    {
                        if (utilidad(granja1) >= 220 * cantidadCompra)
                        {
                            granja1.DineroActual -= cantidadCompra * 220;
                            granja1.Inventario.CantCalabaza = cantidadCompra;
                            Console.WriteLine("Compra realizada correctamente");
                            granja1.MateriaPrimaTotal += cantidadCompra * 220;
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("No tiene los fondos suficientes");
                        }
                    }

                    break;
                case 5:
                    Console.WriteLine("Ingrese la cantidad de espárrago a comprar"); 
                    cantidadCompra = int.Parse(Console.ReadLine());
                    if (cantidadCompra <= 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Cantidad no válida");
                    }
                    else
                    {
                        if (utilidad(granja1) >= 500 * cantidadCompra)
                        {
                            granja1.DineroActual -= cantidadCompra * 500;
                            granja1.Inventario.CantEsparrago = cantidadCompra;
                            granja1.MateriaPrimaTotal += cantidadCompra * 500;
                            Console.WriteLine("Compra realizada correctamente");
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("No tiene los fondos suficientes");
                        }
                    }

                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Opcion de planta ingresada no valida");
                    break;
            }

        }
    }

// calcular los costos proyectados
    static double costosProyectados(Granja granja1)
    {
        return granja1.empleados * granja1.sueldoMensual;
    }

//calcular la utilidad
    static double utilidad(Granja granja1)
    {
        return granja1.DineroActual - costosProyectados(granja1);
    }

//Mostrar informacion de las plantas
    public static void mostrarInfoPlantas()
    {
        Console.ForegroundColor = ConsoleColor.DarkBlue;
        Console.WriteLine("______________________________________________________________________________________");
        Console.WriteLine("|OPCION| |SIEMBRA   | |MESES PARA QUE CREZCA| |COSTO POR SEMILLA| |INGRESO QUE GENERA|");
        Console.WriteLine("|1     | |Trigo     | |1                    | |Q110             | |Q130              |");
        Console.WriteLine("|2     | |Repollo   | |2                    | |Q180             | |Q280              |");
        Console.WriteLine("|3     | |Tomate    | |3                    | |Q250             | |Q450              |");
        Console.WriteLine("|4     | |Calabaza  | |4                    | |Q220             | |Q360              |");
        Console.WriteLine("|5     | |Esparrago | |6                    | |Q500             | |Q1000             |");
        Console.WriteLine("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");
        Console.ForegroundColor= ConsoleColor.Black;
    }

    // accion sembrar
    static void Sembrar(Granja granja1)
    {
        granja1.Inventario.MostrarInfoInventario();
        Console.WriteLine("ingrese la columna en donde desea ingresar la siembra");
        int columnaSiembra = int.Parse(Console.ReadLine());
        Console.WriteLine("ingrese la fila en donde desa ingresar la siembra");
        int filaSiembra = int.Parse(Console.ReadLine());
        if (filaSiembra > granja1.filas)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("FUERA DE LIMITE");
            Console.ForegroundColor = ConsoleColor.Black;
        }
        else if (columnaSiembra > granja1.Columnas)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("FUERA DE LIMITE");
            Console.ForegroundColor = ConsoleColor.Black;
        }
        else
        {

            if (granja1.parcela[filaSiembra, columnaSiembra].Ocupada == true)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("La parcela ya está ocupada");
                Console.ForegroundColor = ConsoleColor.Black;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkYellow; 
                Console.WriteLine("Seleccione qué desea sembrar");
                Console.WriteLine("1. Trigo");
                Console.WriteLine("2. Repollo");
                Console.WriteLine("3. Tomate");
                Console.WriteLine("4. Calabaza");
                Console.WriteLine("5. Esparrago");
                Console.ForegroundColor = ConsoleColor.Black;
                int opcion = int.Parse(Console.ReadLine());
                switch (opcion)
                {
                    case 1:
                        if (granja1.Inventario.CantTrigo > 0)
                        {
                            granja1.parcela[filaSiembra, columnaSiembra].Ocupada = true;
                            granja1.parcela[filaSiembra, columnaSiembra].TipoSiembra = "Trigo";
                            granja1.parcela[filaSiembra, columnaSiembra].MesesRestantes = 1;
                            granja1.parcela[filaSiembra, columnaSiembra].Ingreso = 130;
                            granja1.parcela[filaSiembra, columnaSiembra].Meses = 1;
                            granja1.Inventario.CantTrigo--;
                            Console.WriteLine("Trigo sembrado correctamente");
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("No tiene trigo disponible");
                        }

                        break;
                    case 3:
                        if (granja1.Inventario.CantTomate > 0)
                        {
                            granja1.parcela[filaSiembra, columnaSiembra].Ocupada = true;
                            granja1.parcela[filaSiembra, columnaSiembra].TipoSiembra = "Tomate";
                            granja1.parcela[filaSiembra, columnaSiembra].MesesRestantes = 3;
                            granja1.parcela[filaSiembra, columnaSiembra].Ingreso = 450;
                            granja1.parcela[filaSiembra, columnaSiembra].Meses = 3;
                            granja1.Inventario.CantTomate--;
                            Console.WriteLine("Tomate sembrado correctamente");
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("No tiene tomate disponible");
                        }

                        break;
                    case 2:
                        if (granja1.Inventario.CantRepollo > 0)
                        {
                            granja1.parcela[filaSiembra, columnaSiembra].Ocupada = true;
                            granja1.parcela[filaSiembra, columnaSiembra].TipoSiembra = "Repollo";
                            granja1.parcela[filaSiembra, columnaSiembra].MesesRestantes = 2;
                            granja1.parcela[filaSiembra, columnaSiembra].Ingreso = 280;
                            granja1.parcela[filaSiembra, columnaSiembra].Meses = 2;
                            granja1.Inventario.CantRepollo--;
                            Console.WriteLine("Repollo sembrado correctamente");
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("No tiene repollo disponible");
                        }

                        break;
                    case 4:
                        if (granja1.Inventario.CantCalabaza > 0)
                        {
                            granja1.parcela[filaSiembra, columnaSiembra].Ocupada = true;
                            granja1.parcela[filaSiembra, columnaSiembra].TipoSiembra = "Calabaza";
                            granja1.parcela[filaSiembra, columnaSiembra].MesesRestantes = 4;
                            granja1.parcela[filaSiembra, columnaSiembra].Ingreso = 360;
                            granja1.parcela[filaSiembra, columnaSiembra].Meses = 4;
                            granja1.Inventario.CantCalabaza--;
                            Console.WriteLine("Repollo sembrado correctamente");
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("No tiene calabaza disponible");
                        }

                        break;
                    case 5:
                        if (granja1.Inventario.CantEsparrago > 0)
                        {
                            granja1.parcela[filaSiembra, columnaSiembra].Ocupada = true;
                            granja1.parcela[filaSiembra, columnaSiembra].TipoSiembra = "Esparrago";
                            granja1.parcela[filaSiembra, columnaSiembra].MesesRestantes = 6;
                            granja1.parcela[filaSiembra, columnaSiembra].Ingreso = 1000;
                            granja1.parcela[filaSiembra, columnaSiembra].Meses = 6;
                            granja1.Inventario.CantEsparrago--;
                            Console.WriteLine("Esparrago sembrado correctamente");
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("No tiene Esparrago disponible");
                        }

                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Opcion no valida");
                        break;

                }
            }
        }
    }

// consultar parcelas
    public static void ConsultarParcelas(Granja granja1)
    {
        Console.ForegroundColor = ConsoleColor.Green;
        for (int i = 0; i < granja1.filas; i++)
        {
            for (int j = 0; j < granja1.columnas; j++)
            {
                if (granja1.parcela[i, j].Ocupada == true)
                {
                    Console.Write("[X]");
                }
                else
                {
                    Console.Write("[ ]");
                }
            }

            Console.WriteLine();
        }

        Console.WriteLine("ingrese la fila a consultar");
        int filaConsultar = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("ingrese la columna a consultar");
        int columnaConsultar = Convert.ToInt32(Console.ReadLine());
        if (filaConsultar < 0 || filaConsultar >= granja1.filas || columnaConsultar < 0 ||
            columnaConsultar >= granja1.columnas)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("FUERA DE LIMITE");
            Console.ForegroundColor = ConsoleColor.Black;
        }
        else
        {
            Console.WriteLine("[" + filaConsultar + "," + columnaConsultar + "]");
            granja1.parcela[filaConsultar, columnaConsultar].MostrarInfoParcela();
        }

    }

    // avanzar mes
    public static void AvanzarMes(Granja granja1)
    {
        granja1.DineroActual -= (granja1.empleados * granja1.sueldoMensual);
        Console.ForegroundColor = ConsoleColor.Green;
        double salarios = granja1.empleados * granja1.sueldoMensual;
        Console.WriteLine("Salarios de la mes: " + salarios);
        Console.WriteLine("Dinero actual: " + granja1.DineroActual);
        granja1.ManoObraTotal += salarios;
        granja1.meses--;
        for (int i = 0; i < granja1.filas; i++)
        {
            for (int j = 0; j < granja1.columnas; j++)
            {
                if (granja1.parcela[i, j].Ocupada == true)
                {
                    granja1.parcela[i, j].MesesRestantes--;
                    Console.WriteLine("La parcela [" + i + "," + j + "] avanzó un mes");
                    if (granja1.parcela[i, j].MesesRestantes == 0)
                    {
                        Console.WriteLine("La parcela [" + i + "," + j + "] fue cosechada");
                        Console.WriteLine("Generó Q" + granja1.parcela[i, j].Ingreso);
                        granja1.DineroActual += granja1.parcela[i, j].Ingreso;
                        granja1.IngresosTotales += granja1.parcela[i, j].Ingreso;
                        granja1.parcela[i, j].Ocupada = false;
                        granja1.parcela[i, j].TipoSiembra = "";
                        granja1.parcela[i, j].Ingreso = 0;
                    }
                }
            }
        }
    }

    public static void ReporteFinal(Granja granja1)
    {
        double inventarioProceso = 0;

        for (int i = 0; i < granja1.filas; i++)
        {
            for (int j = 0; j < granja1.columnas; j++)
            {
                if (granja1.parcela[i, j].Ocupada == true)
                {
                    inventarioProceso +=
                        granja1.parcela[i, j].Ingreso;
                }
            }
        }
        double utilidadesFinales = granja1.capitalInicial + granja1.IngresosTotales + inventarioProceso - granja1.ManoObraTotal - granja1.MateriaPrimaTotal;
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("========== REPORTE FINAL ==========");
        Console.WriteLine("Capital inicial: Q" + granja1.capitalInicial);
        Console.WriteLine("Ingresos: Q" + granja1.IngresosTotales);
        Console.WriteLine("Inventario en proceso: Q" + inventarioProceso);
        Console.WriteLine("Mano de obra: Q" + granja1.ManoObraTotal);
        Console.WriteLine("Materia prima: Q" + granja1.MateriaPrimaTotal);
        Console.WriteLine("Utilidades finales: Q" + utilidadesFinales);
    }
}

