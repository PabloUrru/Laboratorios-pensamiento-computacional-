namespace Proyecto2;

public class Parecla
{
    public bool Ocupada;
    public string TipoSiembra;
    public int MesesRestantes;
    public int Ingreso;
    public int Meses;

    public void MostrarInfoParcela() {
        if (this.Ocupada == true) {
            Console.WriteLine("Parcela ocupada"); 
            Console.WriteLine("El tipo de siembra en esta posicion es: " + this.TipoSiembra);
            Console.WriteLine("Los meses restantes para que la siembra crezca son: " + this.MesesRestantes);
            Console.WriteLine("El ingreso esperado es de: " + this.Ingreso);
            Console.WriteLine("Los meses de crecimiento son: " +  MesesCrecimiento());
        }
        else {
            Console.WriteLine("Parcela libre");
            Console.WriteLine("Ingreso esperado: Q0.00"); }
    }
    public int MesesCrecimiento(){
        int MesesCrecimiento = this.Meses - this.MesesRestantes;
        return MesesCrecimiento;
        
    }
    
    
}