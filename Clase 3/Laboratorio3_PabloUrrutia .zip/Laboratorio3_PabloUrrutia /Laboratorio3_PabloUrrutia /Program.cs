﻿// See https://aka.ms/new-console-template for more information

Console.WriteLine("Bienvenido");
Console.WriteLine("Cual es tu nombre? ");
string nombre = Console.ReadLine();
Console.WriteLine("Hola " + nombre);
Console.WriteLine("En que curso se encuentra? ");
string curso = Console.ReadLine();
Console.WriteLine(nombre + " usted tiene 100 en todas las actividades del curso " + curso);
Console.WriteLine("PRESIONE UNA TECLA PARA SALIR");
Console.ReadKey();
