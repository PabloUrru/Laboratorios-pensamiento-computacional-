﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ejercicio 1");
        int[,] arr = new int[5, 5];
        llenararreglo(arr);
        Console.WriteLine("la suma de la primera diagonal es: " + sumaDiagonal(arr));
        Console.WriteLine("la suma de la segunda diagonal es: " + sumaDiagonal2(arr));

        Console.WriteLine("Ejercicio 2");
        int[,] arr2 = new int[4, 6];
        llenararreglo2(arr2);
        Console.WriteLine("la cantidad de numeros pares son:" + numerospares(arr2));
        Console.WriteLine("la cantidad de numeros impares son" + numerosimpares(arr2));

        Console.WriteLine("Ejercicio 3");
        int[,] arr3 = new int[5, 4];
        bool resultado = false;
        llenararregloNotas(arr3);
        for (int i = 0; i < 5; i++)
        {
            float promedio = PromedioEstudiantes(arr3, i);
            Console.WriteLine("El promedio del estudiante es: " + promedio);
            Console.WriteLine("El estudiante arpobo?: " + Aprobado(promedio));
        }

        Console.WriteLine("Ejercicio 4");
        int[,] arr4 = new int[3, 3];
        llenarMatriz(arr4);
        bool simetriap = false;
        Console.WriteLine("la matriz es simetrica: "  + simetria(arr4));

    }

    static void llenararreglo(int[,] a)
    {
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                Console.WriteLine("Ingrese un numero");
                a[i, j] = int.Parse(Console.ReadLine());
            }
        }
    }

    static int sumaDiagonal(int[,] a)
    {
        int suma = a[0, 0] + a[1, 1] + a[2, 2] + a[3, 3] + a[4, 4];
        return suma;
    }

    static int sumaDiagonal2(int[,] a)
    {
        int suma = a[0, 4] + a[1, 3] + a[2, 2] + a[3, 1] + a[4, 0];
        return suma;
    }

    static void llenararreglo2(int[,] a)
    {
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 6; j++)
            {
                Console.WriteLine("Ingrese un numero");
                a[i, j] = int.Parse(Console.ReadLine());
            }
        }
    }

    static int numerospares(int[,] a)
    {
        int pares = 0;
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 6; j++)
            {
                if (a[i, j] % 2 == 0)
                {
                    pares++;
                }
            }
        }

        return pares;
    }

    static int numerosimpares(int[,] a)
    {
        int impares = 0;
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 6; j++)
            {
                if (a[i, j] % 2 != 0)
                {
                    impares++;
                }
            }
        }

        return impares;
    }

    static void llenararregloNotas(int[,] a)
    {
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                Console.WriteLine("Ingrese un numero");
                a[i, j] = int.Parse(Console.ReadLine());

            }
        }
    }

    static float PromedioEstudiantes(int[,] a , int i)
    {
        int suma = 0;
        float promedio = 0;
        for (int j = 0; j < 4; j++)
        {
            suma = a[i, j] + suma;
        }

        promedio = suma / 4;
        return promedio;
    }


    static bool Aprobado(float a)
    {
        if (a >= 61)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    static void llenarMatriz(int[,] a)
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                Console.WriteLine("Ingrese un numero");
                a[i, j] = int.Parse(Console.ReadLine());
            }
        }
    }

    static bool simetria(int[,] a) {
        if (a[0, 1] == a[1, 0] && a[2, 0] == a[0, 2] && a[2, 1] == a[1, 2]) {
            return true; }
        else {
            return false; }
        
    }
}

      
    