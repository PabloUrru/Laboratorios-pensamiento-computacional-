﻿using System;

class Program
{
    static void Main() {
        Console.WriteLine("EJERCICIO 01");
        Console.WriteLine("Digite un numero mayor a 0");
        int numero = Convert.ToInt32(Console.ReadLine());
        if (numero <= 0) 
            Console.WriteLine("Numero invalido");
        else 
            Console.WriteLine("La suma de los digitos del numero es de: " + SumaDigitos(numero));
        
        Console.WriteLine("EJERCICIO 02");
        Console.WriteLine("Ingrese su saldo");
        int saldo = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingrese el monto a retirar");
        int retirado = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(SaldoBancario(ref saldo, ref  retirado));
        
        Console.WriteLine("EJERCICIO 03");
        Console.WriteLine("Ingrese una temperatura en grados celcius");
        double tempe = Convert.ToDouble(Console.ReadLine());
        double tempeFa = 0;
        Console.WriteLine(Temperatura(tempe, ref tempeFa));
        
        Console.WriteLine("EJERCICIO 04");
        int menu = 0;
        int puntos = 0;
        do
        {
            Console.WriteLine("Que accion realizara?");
            Console.WriteLine("1. agregar puntos");
            Console.WriteLine("2. quitar puntos");
            Console.WriteLine("3. obtener nivel");
            Console.WriteLine("4. evaluar estado");
            Console.WriteLine("5. salir");
            menu = Convert.ToInt32(Console.ReadLine());
            
            switch  (menu) {
                case 1:
                    agregarP(ref puntos);
                    break; 
                case 2:
                    quitarP(ref puntos);
                    break;
                case 3:
                    nivel(puntos);
                    break;
                case 4:
                    estado(puntos);
                    break;
                default:
                    Console.WriteLine("Opcion Invalido");
                    break;
            }
        } while (menu != 5);






    }


    static void agregarP(ref int a)
    {
        a += 10;
        if (a > 100)
            a = 100;
        Console.WriteLine("puntos:" + a);
    }
    static void quitarP(ref int a)
    {
        a -= 7;
        if (a < 0)
            a = 0;
        Console.WriteLine("puntos:" + a);
    }

    static void nivel(int a)
    {
        if (a <= 100 && a >= 80) {
            Console.WriteLine("Avanzado"); }
        else if (a >= 50 && a <= 79) {
            Console.WriteLine("intermedio"); }
        else 
            Console.WriteLine("Basico");
    }

    static void estado(int a) {
        if (a == 100) {
            Console.WriteLine("Excelente"); }
        else if (a >= 70 && a <= 99) {
            Console.WriteLine("Aprobado"); }
        else if (a >= 1 && a <= 69)
            Console.WriteLine("Reprobado");
    }
    

    static int SumaDigitos(int a)
    {
        int suma = 0;
        while (a > 0) {
            int digito = a % 10;
            suma = digito + suma; 
            a /= 10;
        }
        return suma;
    }

    static string SaldoBancario(ref int a, ref int b)
    {
        if (a < b) {
            return "saldo =" + a + "(sin cambios)"; }
        else {
            a = a - b;
            return "saldo = " + a; }
        }

    static string Temperatura(double a, ref double b)
    {
        b = (a * 9 / 5) + 32;
        return "la temperatura en grados celcius es de: " + a + "La temperatura en grados Fharenheit es de:" + b;

    }

}