﻿class Program
{
    static void Main()
    {
        Console.WriteLine("EJERCICIO 1");
        Console.WriteLine("Escriba una palabra");
        string palabra = Console.ReadLine(); 
        cantidad(palabra);
        
        Console.WriteLine("EJERCICIO 2");
        Console.WriteLine("Escriba un numero");
        int numero = int.Parse(Console.ReadLine());
        Console.WriteLine("escriba otro numero");
        int numero2 = int.Parse(Console.ReadLine());
        Console.WriteLine("numero 1: " + numero + " numero 2: " + numero2);
        cambio (ref numero,  ref numero2);
        
        Console.WriteLine("EJERCICIO 3");
        Console.WriteLine("Ingrese el precio del boleto");
        double precio = int.Parse(Console.ReadLine());
        Console.WriteLine("Que tipo de cliente es usted? ");
        Console.WriteLine("1.niño (se le aplicara un descuento de 10%)");
        Console.WriteLine("2.adulto mayor (se le aplicara un descuento de 15%)");
        Console.WriteLine("3. cliente premium (se le aplicara un descuento de 9%)");
        Console.WriteLine("4. otro (no tiene descuento) ");
        int tipoCliente = int.Parse(Console.ReadLine());
        descuento(tipoCliente, ref precio);
        
        Console.WriteLine("EJERCICIO 4");
        int menu = 0;
        int puntos = 15;
        do
        {
            Console.WriteLine("Que accion desea realizar?");
            Console.WriteLine("1. recibir daño");
            Console.WriteLine("2. curar");
            Console.WriteLine("3. mostrar salud");
            Console.WriteLine("4. calificar desempeño");
            Console.WriteLine("5. salir");
            menu =  int.Parse(Console.ReadLine());
            switch (menu)
            {
                case 1:
                    recibirDaño(ref puntos);
                    break;
                case 2:
                    curar(ref puntos);
                    break;
                case 3:
                    mostrarSalud(puntos);
                    break;
                case 4:
                    calificarDesempeño(puntos);
                    break;
                case 5:
                    Console.WriteLine("Saliendo");
                    break;
                default:
                    Console.WriteLine("Opción no válida");
                    break;
            }

        } while (menu != 5);

        
    }
    static void cantidad(string palabra ) {
        int longitud = palabra.Length;
        Console.WriteLine(longitud); }

    static void cambio(ref int a,  ref int b)
    {
        int n = a;
        a = b;
        b = n;
        Console.WriteLine("numero 1: " + a + " numero 2: " + b); }

    static void descuento(int a , ref double b) {
        switch (a)
        {
            case 1 :
                Console.WriteLine("el precio original era de : " + b);
                b = b * 0.90;
                Console.WriteLine("su monto es de :" + b);
                break;
            case 2 :
                Console.WriteLine("el precio original era de : " + b);
                b = b * 0.85;
                Console.WriteLine("su monto es de :" + b);
                break;
            case 3 :
                Console.WriteLine("el precio original era de : " + b);
                b = b * 0.91;
                Console.WriteLine("su monto es de :" + b);
                break;
            case 4 :
                Console.WriteLine("el precio original era de : " + b);
                b = b * 1;
                Console.WriteLine("su monto es de :" + b);
                break;
            default:
                Console.WriteLine("tipo de cliente no valido");
                break;
        }
        
        
    }

    static void recibirDaño(ref int a)
    {
        a -= 5;

        if (a < 0)
            a = 0;
    }
    
    static void curar(ref int a)
    {
        a += 3;

        if (a > 15)
            a = 15;
    }
    static void mostrarSalud(int a)
    {
        if (a >= 11)
            Console.ForegroundColor = ConsoleColor.Green;
        else if (a >= 6)
            Console.ForegroundColor = ConsoleColor.Yellow;
        else
            Console.ForegroundColor = ConsoleColor.Red;

        Console.WriteLine("Puntos de salud: " + a);

        Console.ResetColor();
    }
    static void calificarDesempeño(int a)
    {
        Console.ResetColor();

        if (a == 15)
            Console.WriteLine("Calificación: S");
        else if (a >= 11)
            Console.WriteLine("Calificación: A");
        else if (a >= 6)
            Console.WriteLine("Calificación: B");
        else
            Console.WriteLine("Calificación: C");
    }
}