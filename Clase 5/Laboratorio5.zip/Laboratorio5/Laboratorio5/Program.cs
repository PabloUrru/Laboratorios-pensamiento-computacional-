﻿class Program
{
    static void Main()
    {
        Console.WriteLine("EJERCICIO 01");
        Console.WriteLine(" ");
        Console.WriteLine("Ingrese un numero ");
        int numero = Convert.ToInt32(Console.ReadLine());
        if (numero > 0)
        Console.WriteLine("El numero es positivo");
        else if
            (numero < 0)
            Console.WriteLine("El numero es negativo");
        else
        {
            Console.WriteLine("el numero es cero"); }


        Console.WriteLine("EJERCICIO 02");
        Console.WriteLine(" ");
        Console.WriteLine("Ingrese un año");
        int anio =  Convert.ToInt32(Console.ReadLine());
        if (anio%4==0 && anio%100 != 0 )
            Console.WriteLine("El año es bisiesto");
        else if (anio%400==0 )
            Console.WriteLine("El año es bisiesto");
        else {
            Console.WriteLine("El año no es bisiesto"); }
        
        Console.WriteLine("EJERCICIO 03");
        Console.WriteLine(" ");
        Console.WriteLine("Ingrese su salario");
        double salario = Convert.ToDouble(Console.ReadLine());
        bool Multa;
        Console.WriteLine("Usted tiene multa?");
        string Multa2 = Console.ReadLine();
        if (Multa2 == "si")  {
            Multa = true; }
        else{
            Multa = false; }
        int ornato = 0;
        if (salario > 500 && salario <= 1000) {
            ornato = Multa ? 20 : 10; }
        else if (salario > 1000.01 && salario <= 3000) {
            ornato = Multa ? 30 : 15; }
        else if (salario > 3000.01 && salario <= 6000) {
            ornato = Multa ? 100 : 50 ; }
        else if (salario > 6000.01 && salario <= 9000) {
            ornato = Multa ? 150 : 75; }
        else if (salario > 9000.01 && salario <= 12000) {
            ornato = Multa ? 200 : 100; }
        else  {
            ornato = Multa ? 300 : 150; }
        Console.WriteLine("El total a pagar es de: " + ornato);
        
        Console.WriteLine("EJERCICIO 04 ");
        Console.WriteLine(" ");
        Console.WriteLine("Cuantas horas estuvo estacionado?");
        int horas = Convert.ToInt32(Console.ReadLine());
        int monto = horas*10;
        Console.WriteLine("El total a pagar es: " + monto);
        Console.WriteLine("Ingrese su con cuanto va a pagar:");
        int montoPagar = Convert.ToInt32(Console.ReadLine());
        if (montoPagar < monto) {
            Console.WriteLine("error!"); }
        else if (montoPagar == monto) {
            Console.WriteLine("No se requiere cambio! FELIZ TARDE"); }
        else
        {
            int cambio = montoPagar - monto;
            int CambioTotal = cambio;
            int billete100 = cambio / 100;
            cambio = cambio % 100;
            int billete50 = cambio / 50;
            cambio = cambio % 50;
            int billete20 = cambio / 20;
            cambio = cambio % 20;
            int billete10 = cambio / 10;
            cambio = cambio % 10;
            int billete5 = cambio / 5;
            cambio = cambio % 5;
            Console.WriteLine("su cambio es de : " + CambioTotal);
            Console.WriteLine("Billetes de Q100: " + billete100);
            Console.WriteLine("Billetes de Q50: " + billete50);
            Console.WriteLine("Billetes de Q20: " + billete20);
            Console.WriteLine("Billetes de Q10: " + billete10);
            Console.WriteLine("Billetes de Q5: " + billete5);
        }

        Console.ReadKey();
    }
}